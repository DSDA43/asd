This is a project aimed to create some helper class to deal with cryptography in .NET.

## Code standards

- This is a project about cryptography, all code must follow the best practices and standards for security.
- Project uses C# 11 and .NET 8.0.
- Test are written using xUnit.

### Development flow 

- Build: dotnet build "$runningDirectory/src/DotNetCoreCryptography.sln"
- Test: "$runningDirectory/src/DotNetCoreCryptography.Tests/DotNetCoreCryptography.Tests.csproj" 

### Project structure

- `src/`: Main folder for the source code.
- `.config`: Folder with .NET tools configuration files.
- `.github`: Folder with GitHub related files.
- `src/DotnetCoreCryptographyCore`: Main project runningDirectory
- `src/DotNetCoreCryptography.Tests`: Project with tests for the main project.
- `src/DotNetCoreCryptography.Azure`: Implementation of some interface with Azure structures



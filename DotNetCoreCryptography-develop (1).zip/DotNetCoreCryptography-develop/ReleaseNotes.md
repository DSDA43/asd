# DotNetCoreCryptography

## vNext

## 0.6.1

- Added sync version for static Encryptor

## 0.6.0

- Added new version for static Encryptor to encrypt/decrypt strings.

## 0.5.0

- Fixed the build script to include symbols.

## pre 0.6.0

Base version of the library, mostly experimental.

﻿namespace DotNetCoreCryptographyCore
{
    public enum AsymmetricKeyType : byte
    {
        Unknown = 0,
        Rsa4096 = 1,
    }
}
